//
//  TableViewCell.swift
//  EdvoraAssignment
//
//  Created by Pankaj on 19/04/22.
//

import UIKit

class TableViewCell: UITableViewCell {

    
    @IBOutlet weak var cellView: UIView!
    @IBOutlet weak var map_url: UIImageView!
    @IBOutlet weak var imgHash: UIImageView!
    @IBOutlet weak var imgDate: UIImageView!
    @IBOutlet weak var rideID: UILabel!
    @IBOutlet weak var date: UILabel!
    
    
   // var imgUrl = ""
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    
        cellView.layer.cornerRadius = 10
        map_url.layer.cornerRadius = 10
        map_url.layer.maskedCorners = [.layerMaxXMinYCorner, .layerMinXMinYCorner]
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
