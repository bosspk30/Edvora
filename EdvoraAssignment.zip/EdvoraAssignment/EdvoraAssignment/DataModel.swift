//
//  DataModel.swift
//  EdvoraAssignment
//
//  Created by Pankaj on 19/04/22.
//

import Foundation
import SwiftyJSON


class DataModel: NSObject {
    var id = ""
    var date = ""
    var map_url = ""
    var originStat = ""
    var dist = ""
    var state = ""
    var city = ""
    var statPath = [Int]()
   
    
    
    
    class func makeModel(leagueDataArray :JSON) -> DataModel {
  
//            print(leagueDataArray.count)
        let obj = DataModel()
        obj.id = leagueDataArray["id"].stringValue
        obj.date = leagueDataArray["date"].stringValue
        obj.map_url = leagueDataArray["map_url"].stringValue
        obj.city = leagueDataArray["city"].stringValue
        obj.originStat = leagueDataArray["origin_station_code"].stringValue
        obj.dist = leagueDataArray["destination_station_code"].stringValue
        obj.state = leagueDataArray["state"].stringValue
        obj.statPath = leagueDataArray["station_path"].rawValue as! [Int]
            
            
          
        return obj
    }
}
