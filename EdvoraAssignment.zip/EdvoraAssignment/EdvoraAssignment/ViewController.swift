//
//  ViewController.swift
//  EdvoraAssignment
//
//  Created by Pankaj on 18/04/22.
//
import Foundation
import UIKit
import Alamofire
import SwiftyJSON

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource{
    
    let urlString = "https://assessment.api.vweb.app/rides"
    
    var arrOfData = [DataModel]()
    var view1 = UIView()


    @IBOutlet weak var underlineView: UIView!
    
    @IBOutlet weak var btnNearest: UIButton!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var btnUpcoming: UIButton!
    @IBOutlet weak var btnPast: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        self.tableView.delegate = self
        self.tableView.dataSource = self
    
        getApi()
    }
    override func viewWillAppear(_ animated: Bool) {
        
        view1.frame = CGRect(x: 0, y: 0, width: 50, height: 2)
        view1.backgroundColor = .blue
        underlineView.addSubview(view1)
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrOfData.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 250
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") as! TableViewCell
        cell.rideID.text = self.arrOfData[indexPath.row].id
        let statPathArr = arrOfData[indexPath.row].statPath
        let stringStatPathArr = statPathArr.map { String($0) }
      
        let date = self.arrOfData[indexPath.row].date

        cell.date.text = arrOfData[indexPath.row].date
       let url = arrOfData[indexPath.row].map_url
        
        let urlImage:URL = URL(string: url)!

        //MARK: Download image from url
        downloadImage(from: urlImage)
                func getData(from url: URL, completion: @escaping (Data?, URLResponse?, Swift.Error?) -> Swift.Void) {
                        URLSession.shared.dataTask(with: url, completionHandler: completion).resume()
                                    }
                func downloadImage(from url: URL) {
                        getData(from: url) { data, response, error in
                            guard let data = data, error == nil else { return }
//                               print(response?.suggestedFilename ?? url.lastPathComponent)
                                            DispatchQueue.main.sync {
                                                cell.map_url.contentMode = .scaleToFill
                                                cell.map_url.image = UIImage(data: data)
                                            }
                        }
                        }
       
        
        
        return cell
        
       }
     
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc:DetailsVC = DetailsVC.init(nibName: "DetailsVC", bundle: nil)
        vc.date = arrOfData[indexPath.row].date
        vc.rideId = arrOfData[indexPath.row].id
        vc.originStation = arrOfData[indexPath.row].originStat
        vc.distance = arrOfData[indexPath.row].dist
        vc.state = arrOfData[indexPath.row].state
        vc.city = arrOfData[indexPath.row].city
        vc.stationPath = arrOfData[indexPath.row].statPath
        vc.imgMap_url = arrOfData[indexPath.row].map_url
        
//        let urlimg:URL = URL(string: urlString)!
        
        self.present(vc, animated: true)
    }
    
    
    @IBAction func btnActNearest(_ sender: Any) {
        view1.frame = CGRect(x: 0, y: 0, width: 50, height: 2)
        tableView.reloadData()
        btnNearest.titleLabel?.font = UIFont(name: "Arial-BoldMT", size: 18)

    }
    
    
    @IBAction func btnActUpcoming(_ sender: Any) {
        view1.frame = CGRect(x: 90, y: 0, width: 75, height: 2)
        tableView.reloadData()
        btnNearest.titleLabel?.font = UIFont(name: "Arial-BoldMT", size: 18)
    }
    @IBAction func btnActPast(_ sender: Any) {
        view1.frame = CGRect(x: 190, y: 0, width: 40, height: 2)
        tableView.reloadData()
        btnNearest.titleLabel?.font = UIFont(name: "Arial-BoldMT", size: 18)
    }

}

extension ViewController{
    func getApi(){
    let url = "https://assessment.api.vweb.app/rides"
    
    ApiManager.getData(url: url) {(response: JSON?, error:Error?, statusCode: Int) in
        if let error = error{
            print(error)
            return
        }
        if let response = response{
          //  print(response)
            let x = response[]
            for i in 0...x.count-1{
                let obj:DataModel = DataModel.makeModel(leagueDataArray: x[i])
                self.arrOfData.append(obj)
            }
            self.tableView.reloadData()
        }else{
            print("Somthing wrong")
        }
       
        
    }
}
}
