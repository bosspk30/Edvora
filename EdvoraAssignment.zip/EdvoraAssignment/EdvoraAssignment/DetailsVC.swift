//
//  DetailsVC.swift
//  EdvoraAssignment
//
//  Created by Pankaj on 19/04/22.
//

import UIKit

class DetailsVC: UIViewController {

    @IBOutlet weak var map_url: UIImageView!
    @IBOutlet weak var uiView: UIView!
    
    @IBOutlet weak var lblRideID: UILabel!
    @IBOutlet weak var lblOriginStation: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblDistance: UILabel!
    @IBOutlet weak var lblState: UILabel!
    @IBOutlet weak var lblCity: UILabel!
    @IBOutlet weak var lblStaionPath: UILabel!
    

    
    var imgMap_url = ""
    var rideId = ""
    var originStation = ""
    var date = ""
    var distance = ""
    var state = ""
    var city = ""
    var stationPath = [Int]()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let url = imgMap_url
         
        let urlImage:URL = URL(string: url)!

         //MARK: Download image from url
         downloadImage(from: urlImage)
                 func getData(from url: URL, completion: @escaping (Data?, URLResponse?, Swift.Error?) -> Swift.Void) {
                         URLSession.shared.dataTask(with: url, completionHandler: completion).resume()
                                     }
                 func downloadImage(from url: URL) {
                         getData(from: url) { data, response, error in
                             guard let data = data, error == nil else { return }
 //                               print(response?.suggestedFilename ?? url.lastPathComponent)
                                             DispatchQueue.main.sync {
                                                self.map_url.contentMode = .scaleToFill
                                                self.map_url.image = UIImage(data: data)
                                             }
                         }
                         }
        
//        map_url.image = imgMap_url
        lblRideID.text = rideId
        lblOriginStation.text = originStation
        lblDate.text = date
        lblDistance.text = distance
        lblState.text = state
        lblCity.text = city
        var x = ""
        for i in 0...stationPath.count-1{
            x = String(i) + String(i+1)
        }
        lblStaionPath.text = x
        
        
        

        uiView.layer.cornerRadius = 10
        map_url.layer.cornerRadius = 10

       
        
        
    }
    override func viewWillAppear(_ animated: Bool) {
        self.view.frame = CGRect(x: 0, y: 100, width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
    }

    
}
