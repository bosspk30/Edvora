//
//  ApiManager.swift
//  EdvoraAssignment
//
//  Created by Pankaj on 19/04/22.
//

import Foundation
import Alamofire
import SwiftyJSON

class ApiManager: NSObject{
    
class func getData(url:String, completionHandler: @escaping (_ response:JSON?, _ error:Error?, _ status: Int) -> ()) {
        AF.request(url, method: .get, encoding: JSONEncoding.default, headers: nil).responseJSON{
            response in
//            print(response)
            switch response.result{
            case .success(_):
                if let data = response.value{
                            let json = JSON(data)
                            completionHandler(json,nil, response.response!.statusCode)
                        }
            case .failure(_):
                completionHandler(nil, Error.self as! Error, 400)
            }
            
        }
    }
}
